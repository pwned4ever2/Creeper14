//
//  AppDelegate.h
//  c0metjb_rc1
//
//  Created by Ali on 15.02.2021.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

