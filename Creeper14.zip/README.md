# Creeper14


This jailbreak is by the community, and was developed open source.

### Currently implemented: 
setuid(0); <br />
granted .root<br />
sandbox custom r/w perms.<br />
posix_spawn ret 0

# Special Thanks to
@maverickdev1 - utility development<br />
@ModernPwner - CVE (cicuta_virosa)<br />
@brandonplank - sandbox r/w priviliges
@pwned4ever2  - mixing everything up

